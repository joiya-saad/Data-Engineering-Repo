####################### OPERATIONAL LAYER #########################################
drop database soccer_dataset;

CREATE DATABASE soccer_dataset;
USE soccer_dataset;

SET GLOBAL local_infile = 1;

SHOW GLOBAL VARIABLES LIKE 'local_infile';


######## Edit the connection, on the Connection tab, go to the 'Advanced' sub-tab,
######## and in the 'Others:' box add the line OPT_LOCAL_INFILE=1, otherwise it would not import local files  ###########

drop table if exists country;
CREATE TABLE country (
    id INT PRIMARY KEY,
    country_name VARCHAR(255)
);

LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Country.csv'
INTO TABLE country
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),    country_name = NULLIF(country_name, '');

drop table if exists league;
CREATE TABLE league (
    id INT PRIMARY KEY,
    country_id INT,
    league_name VARCHAR(255),
    
	FOREIGN KEY (country_id) REFERENCES country(id)
);

LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\League.csv'
INTO TABLE league
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),    country_id = NULLIF(country_id, ''), league_name = NULLIF(league_name, '');

drop table if exists player;
CREATE TABLE player (
    id INT,
    player_api_id INT PRIMARY KEY,
    player_name varchar(50),
    player_fifa_api_id INT, birthday Date,
	height float, weight float
);

LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Player.csv'
INTO TABLE player
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),    player_fifa_api_id = NULLIF(player_fifa_api_id, ''),    player_api_id = NULLIF(player_api_id, '')
   , height= NULLIF(height, ''), weight= NULLIF(weight, '');



CREATE TABLE player_attributes (
    id INT PRIMARY KEY,
    player_fifa_api_id INT,
    player_api_id INT,
    date datetime,
    overall_rating INT,    potential INT,
    preferred_foot VARCHAR(10),  attacking_work_rate VARCHAR(10), defensive_work_rate VARCHAR(10),
    crossing INT,    finishing INT,    heading_accuracy INT,    short_passing INT,
    volleys INT,    dribbling INT,    curve INT,    free_kick_accuracy INT,
    long_passing INT,    ball_control INT,    acceleration INT,    sprint_speed INT,
    agility INT,    reactions INT,    balance INT,    shot_power INT,
    jumping INT,    stamina INT,    strength INT,    long_shots INT,    aggression INT,
    interceptions INT,    positioning INT,    vision INT,    penalties INT,
    marking INT,    standing_tackle INT,    sliding_tackle INT,    gk_diving INT,
    gk_handling INT,    gk_kicking INT,    gk_positioning INT,    gk_reflexes INT
);

-- Load data from the CSV file into the players table
LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Player_Attributes.csv'
INTO TABLE player_attributes
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),    player_fifa_api_id = NULLIF(player_fifa_api_id, ''),    player_api_id = NULLIF(player_api_id, ''),
    overall_rating = NULLIF(overall_rating, ''),    potential = NULLIF(potential, ''),    preferred_foot = NULLIF(preferred_foot, ''),    attacking_work_rate = NULLIF(attacking_work_rate, ''),
    defensive_work_rate = NULLIF(defensive_work_rate, ''),    crossing = NULLIF(crossing, ''),    finishing = NULLIF(finishing, ''),    heading_accuracy = NULLIF(heading_accuracy, ''),
    short_passing = NULLIF(short_passing, ''),    volleys = NULLIF(volleys, ''),    dribbling = NULLIF(dribbling, ''),    curve = NULLIF(curve, ''),
    free_kick_accuracy = NULLIF(free_kick_accuracy, ''),    long_passing = NULLIF(long_passing, ''),    ball_control = NULLIF(ball_control, ''),    acceleration = NULLIF(acceleration, ''),
    sprint_speed = NULLIF(sprint_speed, ''),    agility = NULLIF(agility, ''),    reactions = NULLIF(reactions, ''),    balance = NULLIF(balance, ''),
    shot_power = NULLIF(shot_power, ''),    jumping = NULLIF(jumping, ''),    stamina = NULLIF(stamina, ''),    strength = NULLIF(strength, ''),
    long_shots = NULLIF(long_shots, ''),    aggression = NULLIF(aggression, ''),    interceptions = NULLIF(interceptions, ''),    positioning = NULLIF(positioning, ''),
    vision = NULLIF(vision, ''),    penalties = NULLIF(penalties, ''),    marking = NULLIF(marking, ''),    standing_tackle = NULLIF(standing_tackle, ''),
    sliding_tackle = NULLIF(sliding_tackle, ''),    gk_diving = NULLIF(gk_diving, ''),    gk_handling = NULLIF(gk_handling, ''),    gk_kicking = NULLIF(gk_kicking, ''),
    gk_positioning = NULLIF(gk_positioning, ''),    gk_reflexes = NULLIF(gk_reflexes, '');


  
drop table if exists team;
CREATE TABLE team (
    id INT,
    team_api_id INT PRIMARY KEY,
    team_fifa_api_id INT,
    team_long_name varchar(50),
    team_short_name varchar(50)
    
);

LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Team.csv'
INTO TABLE team
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),    team_api_id = NULLIF(team_api_id, ''),    team_fifa_api_id = NULLIF(team_fifa_api_id, '')
   , team_long_name= NULLIF(team_long_name, ''), team_short_name= NULLIF(team_short_name, '');



CREATE TABLE team_attributes (
    id INT PRIMARY KEY,    team_fifa_api_id INT,
    team_api_id INT,    date DATETIME,
    buildUpPlaySpeed INT,    buildUpPlaySpeedClass VARCHAR(20),
    buildUpPlayDribbling INT,    buildUpPlayDribblingClass VARCHAR(20),
    buildUpPlayPassing INT,    buildUpPlayPassingClass VARCHAR(20),
    buildUpPlayPositioningClass VARCHAR(20),    chanceCreationPassing INT,
    chanceCreationPassingClass VARCHAR(20),    chanceCreationCrossing INT,
    chanceCreationCrossingClass VARCHAR(20),    chanceCreationShooting INT,
    chanceCreationShootingClass VARCHAR(20),    chanceCreationPositioningClass VARCHAR(20),
    defencePressure INT,    defencePressureClass VARCHAR(20),
    defenceAggression INT,    defenceAggressionClass VARCHAR(20),
    defenceTeamWidth INT,    defenceTeamWidthClass VARCHAR(20),
    defenceDefenderLineClass VARCHAR(20)
    );

-- Load data from the CSV file into the teams table
LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Team_Attributes.csv'
INTO TABLE team_attributes
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
SET
    id = NULLIF(id, ''),
    team_fifa_api_id = NULLIF(team_fifa_api_id, ''),
    team_api_id = NULLIF(team_api_id, ''),
    buildUpPlaySpeed = NULLIF(buildUpPlaySpeed, ''),
    buildUpPlaySpeedClass = NULLIF(buildUpPlaySpeedClass, ''),
    buildUpPlayDribbling = NULLIF(buildUpPlayDribbling, ''),
    buildUpPlayDribblingClass = NULLIF(buildUpPlayDribblingClass, ''),
    buildUpPlayPassing = NULLIF(buildUpPlayPassing, ''),
    buildUpPlayPassingClass = NULLIF(buildUpPlayPassingClass, ''),
    buildUpPlayPositioningClass = NULLIF(buildUpPlayPositioningClass, ''),
    chanceCreationPassing = NULLIF(chanceCreationPassing, ''),
    chanceCreationPassingClass = NULLIF(chanceCreationPassingClass, ''),
    chanceCreationCrossing = NULLIF(chanceCreationCrossing, ''),
    chanceCreationCrossingClass = NULLIF(chanceCreationCrossingClass, ''),
    chanceCreationShooting = NULLIF(chanceCreationShooting, ''),
    chanceCreationShootingClass = NULLIF(chanceCreationShootingClass, ''),
    chanceCreationPositioningClass = NULLIF(chanceCreationPositioningClass, ''),
    defencePressure = NULLIF(defencePressure, ''),
    defencePressureClass = NULLIF(defencePressureClass, ''),
    defenceAggression = NULLIF(defenceAggression, ''),
    defenceAggressionClass = NULLIF(defenceAggressionClass, ''),
    defenceTeamWidth = NULLIF(defenceTeamWidth, ''),
    defenceTeamWidthClass = NULLIF(defenceTeamWidthClass, ''),
    defenceDefenderLineClass = NULLIF(defenceDefenderLineClass, '');


drop table if exists matches;
CREATE TABLE matches (
    id INT PRIMARY KEY, country_id INT, league_id INT,season VARCHAR(20),stage INT,
    matchdate datetime, year int, match_api_id INT,    home_team_api_id INT,    away_team_api_id INT,
    home_team_goal INT,    away_team_goal INT,    home_player_1 INT,    home_player_2 INT,
    home_player_3 INT,    home_player_4 INT,    home_player_5 INT,    home_player_6 INT,
    home_player_7 INT,    home_player_8 INT,    home_player_9 INT,    home_player_10 INT,
    home_player_11 INT,    away_player_1 INT,    away_player_2 INT,    away_player_3 INT,    away_player_4 INT,
    away_player_5 INT,    away_player_6 INT,    away_player_7 INT,    away_player_8 INT,
    away_player_9 INT,    away_player_10 INT,    away_player_11 INT,    goal TEXT,  -- Assumed to store complex or variable data (use TEXT as placeholder)
    shoton TEXT,     shotoff TEXT, foulcommit TEXT, card TEXT, cross_made TEXT, corner TEXT, possession TEXT,
    B365H FLOAT,    B365D FLOAT,    B365A FLOAT,    BWH FLOAT,
    BWD FLOAT,    BWA FLOAT,    IWH FLOAT,    IWD FLOAT,    IWA FLOAT,    LBH FLOAT,    LBD FLOAT,    LBA FLOAT,
    WHH FLOAT,    WHD FLOAT,    WHA FLOAT,    SJH FLOAT,    SJD FLOAT,    SJA FLOAT,    VCH FLOAT,    VCD FLOAT,
    VCA FLOAT,    GBH FLOAT,    GBD FLOAT,    GBA FLOAT,    BSH FLOAT,    BSD FLOAT,    BSA FLOAT,
    
        
    -- Foreign key constraints

    FOREIGN KEY (league_id) REFERENCES league(id),
    FOREIGN KEY (home_team_api_id) REFERENCES team(team_api_id),
    FOREIGN KEY (away_team_api_id) REFERENCES team(team_api_id)
);

LOAD DATA LOCAL INFILE 'C:\\Users\\saad\\Documents\\Data Engineering\\Data Engineering 1\\Term Project 1\\European Soccer Dataset\\Match.csv'
INTO TABLE matches
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
( id, country_id , league_id ,season ,stage ,
    @matchdate, match_api_id ,    home_team_api_id ,    away_team_api_id ,
    home_team_goal ,    away_team_goal ,    home_player_1 ,    home_player_2 ,
    home_player_3 ,    home_player_4 ,    home_player_5 ,    home_player_6 ,
    home_player_7 ,    home_player_8 ,    home_player_9 ,    home_player_10 ,
    home_player_11 ,    away_player_1 ,    away_player_2 ,    away_player_3 ,    away_player_4 ,
    away_player_5 ,    away_player_6 ,    away_player_7 ,    away_player_8 ,
    away_player_9 ,    away_player_10 ,    away_player_11 ,    goal , 
    shoton ,     shotoff , foulcommit , card , cross_made , corner , possession ,
    B365H ,    B365D ,    B365A ,    BWH ,
    BWD ,    BWA ,    IWH ,    IWD ,    IWA ,    LBH ,    LBD ,    LBA ,
    WHH ,    WHD ,    WHA ,    SJH ,    SJD ,    SJA ,    VCH ,    VCD ,
    VCA ,    GBH ,    GBD ,    GBA ,    BSH ,    BSD ,    BSA )
SET
 id = NULLIF(id, ''),    country_id = NULLIF(country_id, ''),
    league_id = NULLIF(league_id, ''), season = NULLIF(season, ''),
    stage = NULLIF(stage, ''), matchdate = STR_TO_DATE(@matchdate, '%m/%d/%Y'),   year = YEAR(matchdate),  match_api_id = NULLIF(match_api_id, ''),    home_team_api_id = NULLIF(home_team_api_id, ''),
    away_team_api_id = NULLIF(away_team_api_id, ''),    home_team_goal = NULLIF(home_team_goal, ''),
    away_team_goal = NULLIF(away_team_goal, ''), 
    home_player_1 = NULLIF(home_player_1, ''), home_player_2 = NULLIF(home_player_2, ''), home_player_3 = NULLIF(home_player_3, ''),
    home_player_4 = NULLIF(home_player_4, ''),    home_player_5 = NULLIF(home_player_5, ''),    home_player_6 = NULLIF(home_player_6, ''),    home_player_7 = NULLIF(home_player_7, ''),
    home_player_8 = NULLIF(home_player_8, ''),    home_player_9 = NULLIF(home_player_9, ''),    home_player_10 = NULLIF(home_player_10, ''),    home_player_11 = NULLIF(home_player_11, ''),
    away_player_1 = NULLIF(away_player_1, ''),    away_player_2 = NULLIF(away_player_2, ''),    away_player_3 = NULLIF(away_player_3, ''),    away_player_4 = NULLIF(away_player_4, ''),
    away_player_5 = NULLIF(away_player_5, ''),    away_player_6 = NULLIF(away_player_6, ''),    away_player_7 = NULLIF(away_player_7, ''),    away_player_8 = NULLIF(away_player_8, ''),
    away_player_9 = NULLIF(away_player_9, ''),    away_player_10 = NULLIF(away_player_10, ''),    away_player_11 = NULLIF(away_player_11, ''),    goal = NULLIF(goal, ''),    shoton = NULLIF(shoton, ''),
    shotoff = NULLIF(shotoff, ''),    foulcommit = NULLIF(foulcommit, ''),    card = NULLIF(card, ''),    cross_made = NULLIF(cross_made, ''),
    corner = NULLIF(corner, ''),    possession = NULLIF(possession, ''),    B365H = NULLIF(B365H, ''),    B365D = NULLIF(B365D, ''),
    B365A = NULLIF(B365A, ''),    BWH = NULLIF(BWH, ''),    BWD = NULLIF(BWD, ''),    BWA = NULLIF(BWA, ''),
    IWH = NULLIF(IWH, ''),    IWD = NULLIF(IWD, ''),    IWA = NULLIF(IWA, ''),    LBH = NULLIF(LBH, ''),
    LBD = NULLIF(LBD, ''),    LBA = NULLIF(LBA, ''),    WHH = NULLIF(WHH, ''),    WHD = NULLIF(WHD, ''),
    WHA = NULLIF(WHA, ''),    SJH = NULLIF(SJH, ''),    SJD = NULLIF(SJD, ''),    SJA = NULLIF(SJA, ''),
    VCH = NULLIF(VCH, ''),    VCD = NULLIF(VCD, ''),    VCA = NULLIF(VCA, ''),    GBH = NULLIF(GBH, ''),
    GBD = NULLIF(GBD, ''),    GBA = NULLIF(GBA, ''),    BSH = NULLIF(BSH, ''),    BSD = NULLIF(BSD, ''),
    BSA = NULLIF(BSA, '');
    
    


#################################### ETL Pipeline and Analytical Layer ################################3

USE soccer_dataset;

################## CREATING A DENORMALIZED TABLE WITH INFORMATION OF ALL 25K MATCHES WITH RELEVANT TEAMS, SCORES, POINTS, TACTICS, PLAYERS AND OTHER INFORMATION

DROP PROCEDURE IF EXISTS CreateAllMatchesInformation;

DELIMITER //

CREATE PROCEDURE CreateAllMatchesInformation()
BEGIN


	drop table if exists Match_Information;
	Create table Match_Information AS 
	select a.id,
	a.country_id,
	b.country_name,
	a.league_id,
	c.league_name,
	a.season,
	a.matchdate,
	a.home_team_api_id,
	a.away_team_api_id,
	d.team_long_name as home_team,
	e.team_long_name as away_team,
	IFNULL(a.home_team_goal,0) as home_team_goal,
	IFNULL(a.away_team_goal,0) as away_team_goal,
	CASE WHEN IFNULL(a.home_team_goal,0) > IFNULL(a.away_team_goal,0) then 3
	when IFNULL(a.home_team_goal,0) = IFNULL(a.away_team_goal,0) then 1 
	else 0 end as HomeTeamPoints,
	CASE WHEN IFNULL(a.home_team_goal,0) < IFNULL(a.away_team_goal,0) then 3
	when IFNULL(a.home_team_goal,0) = IFNULL(a.away_team_goal,0) then 1 
	else 0 end as AwayTeamPoints,
	case when (LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1) ,2
		) like '%<%' or LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1) ,2
		) like '%<%') then 50 else LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1) ,2
		) end AS home_possession,
	case when (LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1) ,2
		) like '%<%' or LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1) ,2
		) like '%<%') then 50 else LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(a.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1) ,2
		) end AS away_possession,
	a.B365H, a.B365D, a.B365A,
	f.BuildUpPlaySpeedClass as HomeTeamBuildUpPlayClass,
	f.chancecreationpassingclass as HomeTeamChanceCreationClass,
	f.defencePressureClass as HomeTeamDefencePressureClass,
	g.BuildUpPlaySpeedClass as AwayTeamBuildUpPlayClass,
	g.chancecreationpassingclass as AwayTeamChanceCreationClass,
	g.defencePressureClass as AwayTeamDefencePressureClass,
	a.home_player_1, a.home_player_2, a.home_player_3,a.home_player_4, a.home_player_5, a.home_player_6,a.home_player_7, a.home_player_8, a.home_player_9,a.home_player_10, a.home_player_11,
	a.away_player_1, a.away_player_2, a.away_player_3,a.away_player_4, a.away_player_5, a.away_player_6,a.away_player_7, a.away_player_8, a.away_player_9,a.away_player_10, a.away_player_11
	from soccer_dataset.matches as a
	left join soccer_dataset.league as c
	on c.id = a.league_id
	left join soccer_dataset.country as b
	on c.country_id = b.id
	left join soccer_dataset.team as d
	on a.home_team_api_id = d.team_api_id
	left join soccer_dataset.team as e
	on a.away_team_api_id = e.team_api_id
	left join soccer_dataset.team_attributes as f
	on a.home_team_api_id = f.team_api_id
	and year(f.date) = year(a.matchdate)
	left join soccer_dataset.team_attributes as g
	on a.away_team_api_id = g.team_api_id
	and year(g.date) = year(a.matchdate)
	;

END //
DELIMITER ;


CALL CreateAllMatchesInformation();


################### Creating a trigger to update match information in case of new match information

drop trigger if exists after_match_insert;

DELIMITER $$


CREATE TRIGGER after_match_insert
AFTER INSERT ON soccer_dataset.matches
FOR EACH ROW
BEGIN
    INSERT INTO Match_Information
    SELECT 
    
        NEW.id,
        NEW.country_id,
        b.country_name,
        NEW.league_id,
        c.league_name,
        NEW.season,
        NEW.matchdate,
        NEW.home_team_api_id,
        NEW.away_team_api_id,
        d.team_long_name AS home_team,
        e.team_long_name AS away_team,
        IFNULL(NEW.home_team_goal,0) AS home_team_goal,
        IFNULL(NEW.away_team_goal,0) AS away_team_goal,
        CASE WHEN IFNULL(NEW.home_team_goal,0) > IFNULL(NEW.away_team_goal,0) THEN 3
             WHEN IFNULL(NEW.home_team_goal,0) = IFNULL(NEW.away_team_goal,0) THEN 1 
             ELSE 0 END AS HomeTeamPoints,
        CASE WHEN IFNULL(NEW.home_team_goal,0) < IFNULL(NEW.away_team_goal,0) THEN 3
             WHEN IFNULL(NEW.home_team_goal,0) = IFNULL(NEW.away_team_goal,0) THEN 1 
             ELSE 0 END AS AwayTeamPoints,
        CASE WHEN (LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1), 2) LIKE '%<%' OR
                  LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1), 2) LIKE '%<%') THEN 50
             ELSE LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1), 2) END AS home_possession,
        CASE WHEN (LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1), 2) LIKE '%<%' OR
                  LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<homepos>', -1), 2) LIKE '%<%') THEN 50
             ELSE LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.possession, '<elapsed>90</elapsed>', -1), '<awaypos>', -1), 2) END AS away_possession,
        NEW.B365H, NEW.B365D, NEW.B365A,
        f.BuildUpPlaySpeedClass AS HomeTeamBuildUpPlayClass,
        f.chancecreationpassingclass AS HomeTeamChanceCreationClass,
        f.defencePressureClass AS HomeTeamDefencePressureClass,
        g.BuildUpPlaySpeedClass AS AwayTeamBuildUpPlayClass,
        g.chancecreationpassingclass AS AwayTeamChanceCreationClass,
        g.defencePressureClass AS AwayTeamDefencePressureClass,
        NEW.home_player_1, NEW.home_player_2, NEW.home_player_3, NEW.home_player_4, 
        NEW.home_player_5, NEW.home_player_6, NEW.home_player_7, NEW.home_player_8, 
        NEW.home_player_9, NEW.home_player_10, NEW.home_player_11,
        NEW.away_player_1, NEW.away_player_2, NEW.away_player_3, NEW.away_player_4, 
        NEW.away_player_5, NEW.away_player_6, NEW.away_player_7, NEW.away_player_8, 
        NEW.away_player_9, NEW.away_player_10, NEW.away_player_11
    FROM soccer_dataset.matches a
    LEFT JOIN soccer_dataset.country b ON NEW.country_id = b.id
    LEFT JOIN soccer_dataset.league c ON NEW.league_id = c.id
    LEFT JOIN soccer_dataset.team d ON NEW.home_team_api_id = d.team_api_id
    LEFT JOIN soccer_dataset.team e ON NEW.away_team_api_id = e.team_api_id
    LEFT JOIN soccer_dataset.team_attributes f ON NEW.home_team_api_id = f.team_api_id AND YEAR(f.date) = YEAR(NEW.matchdate)
    LEFT JOIN soccer_dataset.team_attributes g ON NEW.away_team_api_id = g.team_api_id AND YEAR(g.date) = YEAR(NEW.matchdate)
where a.id = NEW.id;
END $$

DELIMITER ;


######## TESTING TRIGGER ###################
/*
INSERT INTO soccer_dataset.matches
(id, country_id, league_id, season, matchdate, home_team_api_id, away_team_api_id, home_team_goal, away_team_goal, possession, B365H, B365D, B365A, home_player_1, home_player_2, home_player_3, home_player_4, home_player_5, home_player_6, home_player_7, home_player_8, home_player_9, home_player_10, home_player_11, away_player_1, away_player_2, away_player_3, away_player_4, away_player_5, away_player_6, away_player_7, away_player_8, away_player_9, away_player_10, away_player_11)
VALUES
(24021994, 1729, 1729, '2013/2014', '2013-10-01', 8455, 9825, 2, 1, '<elapsed>90</elapsed><homepos>60</homepos><awaypos>40</awaypos>', 1.50, 3.75, 5.00, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211);

SELECT * FROM match_information WHERE id = 24021994;

*/


############## CREATING A DENORMALIZED TABLE WITH CONTAINS PLAYER INFORMATION LIKE NAME, COUNTRY, FIFA RATING AND ALL STATISTICS OF THEIR CORRESPONDING TEAM


DROP PROCEDURE IF EXISTS CreateAllPlayersInformation;

DELIMITER //

CREATE PROCEDURE CreateAllPlayersInformation()
BEGIN

	Drop table if exists players_information;
    CREATE TABLE players_information (
        id INT,
        league_name VARCHAR(255),
        country_name VARCHAR(255),
        season VARCHAR(255),
        matchdate DATE,
        team_id INT,
        team_name VARCHAR(255),
        team_goals INT,
        opponent_goals INT,
        points INT,
        player_id INT,
        player_type VARCHAR(10),
        player_name VARCHAR(255),
        player_rating FLOAT,
        player_potential FLOAT,
        PRIMARY KEY (id, player_id)  -- Composite primary key to uniquely identify player in match context

    );
    
    INSERT IGNORE INTO players_information (id, league_name, country_name, season, matchdate, team_id, team_name, team_goals, opponent_goals, points, player_id, player_type, player_name, player_rating, player_potential)
	Select players.*, player_info.player_name, player_ratings.overall_rating as player_rating, player_ratings.potential as player_potential
	from
	(
	SELECT 
		id,
		league_name,
		country_name,
		season,
		matchdate,
		home_team_api_id AS team_id,
		home_team as team_name,
		home_team_goal AS team_goals,
		away_team_goal AS opponent_goals,
		HomeTeamPoints as points,
		home_player AS player_id,
		'home' AS player_type
	FROM (
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			  home_player_1 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_2 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_3 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_4 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_5 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_6 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_7 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_8 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_9 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_10 AS home_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name,country_name,season, matchdate, home_team_api_id,home_team, home_team_goal, away_team_goal,HomeTeamPoints,
			   home_player_11 AS home_player FROM soccer_dataset.Match_Information
	) AS home_players

	UNION ALL

	SELECT 
		id,
		league_name,
		country_name,
		season,
		matchdate,
		away_team_api_id AS team_id,
		away_team as team_name,
		away_team_goal AS team_goals,
		home_team_goal AS opponent_goals,
		AwayTeamPoints as points,
		away_player AS player_id,
		'away' AS player_type
	FROM (
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_1 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_2 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_3 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_4 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_5 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_6 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_7 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_8 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_9 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_10 AS away_player FROM soccer_dataset.Match_Information
		UNION ALL       
		SELECT id, league_name, country_name, season, matchdate, away_team_api_id, away_team, away_team_goal, home_team_goal, AwayTeamPoints,
			   away_player_11 AS away_player FROM soccer_dataset.Match_Information
	) AS away_players
	) as players
	left join soccer_dataset.player as player_info
	on player_info.player_api_id = players.player_id
	left join (
	select player_api_id, Year(date) as dateyear, avg(overall_rating) as overall_rating, avg(potential) as potential
	from soccer_dataset.player_attributes
	group by player_api_id, Year(date)
	) as player_ratings
	on player_ratings.player_api_id = players.player_id
	and player_ratings.dateyear = year(players.matchdate)
	where players.player_id is not null;
	
    
    
    ALTER TABLE players_information
    ADD FOREIGN KEY (player_id) REFERENCES soccer_dataset.player(player_api_id);  -- Player foreign key

END //
DELIMITER ;


CALL CreateAllPlayersInformation();

#################### USING A SCHEDULER INSTEAD OF TRIGGER TO RECREATE TABLE WITH UPDATED PLAYER_INFORMATION USING MATCH_INFORMATION

DROP EVENT IF EXISTS update_players_information_event;

DELIMITER $$

CREATE EVENT update_players_information_event
ON SCHEDULE EVERY 30 DAY
DO
BEGIN
    CALL CreateAllPlayersInformation(); -- Call the existing stored procedure
END$$

DELIMITER ;

############### TESTING THE SCHEDULER FOR DENORMALIZED PLAYERS_INFORMATION #####################
/*
SELECT * FROM information_schema.EVENTS WHERE EVENT_NAME = 'update_players_information_event';
*/



######################## DATA MART ###############################################

#################### ALL STORED PROCEDURES FOR CREATING DESIRED OUTPUT TABLES CREATED BELOW, THEN WE CREATE SCHEDULER THAT ENCOMPASSES ALL

################# 1. TEAM PERFORMANCE VIEW BY SEASONS

Use soccer_dataset;


DROP PROCEDURE IF EXISTS CreateTeamStatisticsBySeasons;
DELIMITER //
CREATE PROCEDURE CreateTeamStatisticsBySeasons()
BEGIN

drop view if exists team_statistics_by_seasons;
create view Team_Statistics_by_Seasons AS
	select home_stats.season, home_stats.league_name,home_stats.team_id, home_stats.team_name, 
	RANK() OVER (PARTITION BY season, league_name ORDER BY (home_points_acheived + away_points_acheived) DESC,((home_goals_scored+ away_goals_scored) - (home_goals_conceded + away_goals_conceded)) DESC) AS Team_Rank,
	home_points_acheived + away_points_acheived as total_points_acheived,
	home_goals_scored+ away_goals_scored as total_goals_scored,
	  home_goals_conceded + away_goals_conceded as total_goals_conceded,
	  (home_goals_scored+ away_goals_scored) - (home_goals_conceded + away_goals_conceded) total_goal_difference,
	  home_matches_played+ away_matches_played as total_matches_played,
	   (avg_home_possession + avg_away_possession)/2 as total_avg_possession,
	  home_points_acheived, away_points_acheived,   home_goals_scored, away_goals_scored,
	 home_goals_conceded, away_goals_conceded,
	home_matches_played,home_wins,home_losses,home_draws, away_matches_played,away_wins, away_losses,away_draws, round(avg_home_possession,0) as avg_home_possession, round(avg_away_possession,0) as avg_away_possession
from (
(SELECT 
    season,
    league_name,
    home_team_api_id AS team_id,
    home_team AS team_name,
    SUM(HomeTeamPoints) AS home_points_acheived,
    SUM(home_team_goal) AS home_goals_scored,
    SUM(away_team_goal) AS home_goals_conceded,
    COUNT(*) AS home_matches_played,
    sum(case when hometeampoints = 3 then 1 else 0 end) as home_wins,
        sum(case when hometeampoints = 0 then 1 else 0 end) as home_losses,
            sum(case when hometeampoints = 1 then 1 else 0 end) as home_draws,
    avg(home_possession) as avg_home_possession
FROM 
    soccer_dataset.match_information  -- Replace with your actual table name
GROUP BY 
    season, league_name, home_team_api_id, home_team
) as home_stats
left join (
SELECT 
    season,
    league_name,
    away_team_api_id AS team_id,
    away_team AS team_name,
    SUM(AwayTeamPoints) AS away_points_acheived,
    SUM(away_team_goal) AS away_goals_scored,
    SUM(home_team_goal) AS away_goals_conceded,
    COUNT(*) AS away_matches_played,
	sum(case when awayteampoints = 3 then 1 else 0 end) as away_wins,
        sum(case when awayteampoints = 0 then 1 else 0 end) as away_losses,
            sum(case when awayteampoints = 1 then 1 else 0 end) as away_draws,
	avg(away_possession) as avg_away_possession
FROM 
    soccer_dataset.match_information
GROUP BY 
    season, league_name, away_team_api_id, away_team
    ) as away_stats
    on home_stats.season = away_stats.season
    and home_stats.league_name = away_stats.league_name
    and home_stats.team_name = away_stats.team_name
    )
    order by season, league_name, total_points_acheived desc, total_goal_difference desc
    ;

END //
DELIMITER ;    


################# 2. TEAMS (HAVING > 100 MATCHES) RANKING BY OVERALL WIN PERCENTAGE AND OTHER STATISTICS FOR PERIOD 2008 TILL 2016    

DROP PROCEDURE IF EXISTS CreateTeamsProfile2008_2016;
DELIMITER //
CREATE PROCEDURE CreateTeamsProfile2008_2016()
BEGIN

    
drop view if exists Teams_Profile_2008_2016;
create view Teams_Profile_2008_2016 AS
select league_name, team_name, 
	sum(total_matches_played) as total_matches,
    sum(total_points_acheived) as total_points,
	(sum(home_wins+away_wins)/sum(total_matches_played))*100 as win_percentage,
    (sum(home_losses+away_losses)/sum(total_matches_played))*100 as loss_percentage,
    (sum(home_draws+away_draws)/sum(total_matches_played))*100 as draw_percentage,
    sum(total_points_acheived)/sum(total_matches_played) as points_per_match,
	sum(home_wins+away_wins) as total_wins,
    sum(home_losses+away_losses) as total_losses,
    sum(home_draws+away_draws) as total_draws,
    sum(total_goals_scored) as total_goals_scored,
    sum(total_goals_conceded) as total_goals_conceded,
    avg(total_avg_possession) as avg_possession_per_game
from soccer_dataset.team_statistics_by_seasons
group by league_name, team_name
having total_matches > 100
order by win_percentage desc;

END //
DELIMITER ; 
    
################# 3. PLAYER PERFORMANCE VIEW BY SEASONS    
DROP PROCEDURE IF EXISTS CreatePlayersStatisticsbySeasons;
DELIMITER //
CREATE PROCEDURE CreatePlayersStatisticsbySeasons()
BEGIN

drop view if exists Players_Statistics_by_Seasons;
create view Players_Statistics_by_Seasons AS
select season, league_name, team_name, player_name, 
    avg(player_rating) as avg_rating,
    count(distinct id) as total_matches,
    sum(points) as total_points,
    sum(points)/count(distinct id) as points_per_match,
    (sum(case when points = 3 then 1 else 0 end)/count(distinct id))*100 as win_percentage,
    (sum(case when points = 0 then 1 else 0 end)/count(distinct id))*100 as loss_percentage,
    (sum(case when points = 1 then 1 else 0 end)/count(distinct id))*100 as draw_percentage,
	sum(case when points = 3 then 1 else 0 end) as total_wins,
    sum(case when player_type = 'home' and points = 3 then 1 else 0 end) as home_wins,
    sum(case when player_type = 'away' and points = 3 then 1 else 0 end) as away_wins,
    sum(case when points = 0 then 1 else 0 end) as total_losses,
    sum(case when player_type = 'home' and points = 0 then 1 else 0 end) as home_losses,
    sum(case when player_type = 'away' and points = 0 then 1 else 0 end) as away_losses,
    sum(case when points = 1 then 1 else 0 end) as total_draws
from soccer_dataset.players_information
group by season, league_name, team_name, player_name;
        
END //
DELIMITER ; 



############## 4. PLAYERS (HAVING > 100 MATCHES) RANKING BY OVERALL WIN PERCENTAGE AND OTHER STATISTICS FOR PERIOD 2008 TILL 2016       

DROP PROCEDURE IF EXISTS CreatePlayersProfile2008_2016;
DELIMITER //
CREATE PROCEDURE CreatePlayersProfile2008_2016()
BEGIN


drop view if exists Players_Profile_2008_2016;
create view Players_Profile_2008_2016 AS
select player_name, 
	count(distinct id) as total_matches,
    sum(points) as total_points,
	(sum(case when points = 3 then 1 else 0 end)/count(distinct id))*100 as win_percentage,
    (sum(case when points = 0 then 1 else 0 end)/count(distinct id))*100 as loss_percentage,
    (sum(case when points = 1 then 1 else 0 end)/count(distinct id))*100 as draw_percentage,
    sum(points)/count(distinct id) as points_per_match,
	sum(case when points = 3 then 1 else 0 end) as total_wins,
    sum(case when points = 0 then 1 else 0 end) as total_losses,
    sum(case when points = 1 then 1 else 0 end) as total_draws
from soccer_dataset.players_information
group by player_name
having total_matches > 100
order by win_percentage desc;

END //
DELIMITER ; 
    
    
############# 5. TEAMS UNPIVOTED RANKING PER SEASON FOR PERIOD 2008 TILL 2016       

DROP PROCEDURE IF EXISTS CreateUnpivotedTeamRanksOverTime2008_2016;
DELIMITER //
CREATE PROCEDURE CreateUnpivotedTeamRanksOverTime2008_2016()
BEGIN

    
drop view if exists Team_Ranks_Over_Time_2008_2016;
create view Team_Ranks_Over_Time_2008_2016 AS   
	SELECT 
	league_name,
	team_name,
	IFNULL(MAX(CASE WHEN season = '2008/2009' THEN team_rank END), 'In Lower League') AS `2008/2009`,
	IFNULL(MAX(CASE WHEN season = '2009/2010' THEN team_rank END), 'In Lower League')  AS `2009/2010`,
	IFNULL(MAX(CASE WHEN season = '2010/2011' THEN team_rank END), 'In Lower League')  AS `2010/2011`,
	IFNULL(MAX(CASE WHEN season = '2011/2012' THEN team_rank END), 'In Lower League')  AS `2011/2012`,
	IFNULL(MAX(CASE WHEN season = '2012/2013' THEN team_rank END), 'In Lower League')  AS `2012/2013`,
	IFNULL(MAX(CASE WHEN season = '2013/2014' THEN team_rank END), 'In Lower League') AS `2013/2014`,
	IFNULL(MAX(CASE WHEN season = '2014/2015' THEN team_rank END), 'In Lower League') AS `2014/2015`,
	IFNULL(MAX(CASE WHEN season = '2015/2016' THEN team_rank END), 'In Lower League') AS `2015/2016`
FROM soccer_dataset.team_statistics_by_seasons
GROUP BY league_name, team_name
ORDER BY league_name,team_name;

END //
DELIMITER ; 


############# 6. DEFENSE, MIDFIELD AND OFFENSE TACTICS FOR EVERY CHAMPION TEAM FROM EACH LEAGUE OVER DIFFERENT SEASONS 

DROP PROCEDURE IF EXISTS CreateLeagueWinnersTacticsOverTime;
DELIMITER //
CREATE PROCEDURE CreateLeagueWinnersTacticsOverTime()
BEGIN


drop view if exists League_Winners_Tactics_Over_Time;
create view League_Winners_Tactics_Over_Time AS 
	Select a.Season, a.league_name,a.team_id, a.team_name as League_Winner,
    b.buildUpPlayPositioningClass,b.buildUpPlaySpeedClass, b.buildUpPlayDribblingClass, b.buildUpPlayPassingClass,
    b.chanceCreationCrossingClass,b.chanceCreationPassingClass,b.chanceCreationPositioningClass, b.chanceCreationShootingClass,
    b.defenceAggressionClass, b.defenceDefenderLineClass,b.defencePressureClass,b.defenceTeamWidthClass
FROM soccer_dataset.team_statistics_by_seasons as a
left join soccer_dataset.team_attributes as b
on left(a.season,4) = year(b.date)
and a.team_id = b.team_api_id
where a.Team_Rank = 1 and b.buildUpPlayDribblingClass is not null
order by league_name, season
;

END //
DELIMITER ; 

############# 7. BET365 ODDS PLACEMENT SUCCESS RATE BY SEASON AND LEAGUE
 
#### we take the lowest odd (highest probability) of the three outcomes (home win, away win, draw) as put by
### BET365 and check the % of matches in which their lowest odd matched with the actual outcome 

DROP PROCEDURE IF EXISTS CreateBET365OddsSuccessRate;
DELIMITER //
CREATE PROCEDURE CreateBET365OddsSuccessRate()
BEGIN


drop view if exists BET365_Odds_Success_Rate;
Create view BET365_Odds_Success_Rate AS 
Select Season, league_name,
    (sum(case when ((B365H < B365A and B365H < B365D and HomeTeamPoints = 3)
    or (B365A < B365H and B365A < B365D and AwayTeamPoints = 3)
    or (B365D < B365H and B365D < B365A and HomeTeamPoints = 1)) then 1 else 0 end)/count(distinct id))*100 as OutcomePredictionSuccessPercentage
FROM soccer_dataset.match_information 
where B365H is not null and B365A is not null and B365D is not null
group by Season,league_name
order by season,league_name
;
END //
DELIMITER ; 



#################### USING A SCHEDULER TO UPDATE ALL DATA MART VIEWS CREATED


DROP EVENT IF EXISTS update_data_mart_views;

DELIMITER $$

CREATE EVENT update_data_mart_views
ON SCHEDULE EVERY 30 DAY
DO
BEGIN
    CALL CreateTeamStatisticsBySeasons(); 
    CALL CreateTeamsProfile2008_2016(); 
    CALL CreatePlayersStatisticsbySeasons(); 
    CALL CreatePlayersProfile2008_2016(); 
    CALL CreateUnpivotedTeamRanksOverTime2008_2016(); 
    CALL CreateLeagueWinnersTacticsOverTime(); 
    CALL CreateBET365OddsSuccessRate(); 
   
END$$

DELIMITER ;

